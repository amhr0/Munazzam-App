#!/bin/bash
# Create simple placeholder icons
# In production, replace with proper logo

# Create SVG icon
cat > icon.svg << 'SVGEOF'
<svg width="128" height="128" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="128" height="128" rx="24" fill="url(#grad)"/>
  <text x="64" y="80" font-family="Arial" font-size="60" fill="white" text-anchor="middle" font-weight="bold">م</text>
</svg>
SVGEOF

echo "Icon created. Use online tools to convert SVG to PNG in different sizes (16, 32, 48, 128)"
